from setuptools import setup, find_packages

setup(
        name="petrichor-api-tools",
        version="0.0.1",
        packages=find_packages(),
        author="Wes Doyle",
        author_email="foo@example.com",
        url="productivedev.com",
)
