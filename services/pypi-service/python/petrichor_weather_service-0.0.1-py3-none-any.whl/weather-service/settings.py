WEATHER_API_URL = "https://samples.openweathermap.org/data/2.5/weather"  # ?zip=94040,us
